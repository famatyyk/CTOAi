--
-- PostgreSQL database dump
--

\restrict eW4yCDqWLXNPjvnwVv1UxdYMhiLu2SuI1GtsqmoJJfgUR8CRzGd3rk5z0gYUX9Z

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: trg_set_updated_at(); Type: FUNCTION; Schema: public; Owner: ctoa
--

CREATE FUNCTION public.trg_set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;


ALTER FUNCTION public.trg_set_updated_at() OWNER TO ctoa;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: ctoa
--

CREATE TABLE public.accounts (
    id integer NOT NULL,
    username text NOT NULL,
    password_hash text NOT NULL,
    role text DEFAULT 'operator'::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.accounts OWNER TO ctoa;

--
-- Name: accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: ctoa
--

CREATE SEQUENCE public.accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.accounts_id_seq OWNER TO ctoa;

--
-- Name: accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ctoa
--

ALTER SEQUENCE public.accounts_id_seq OWNED BY public.accounts.id;


--
-- Name: agent_runs; Type: TABLE; Schema: public; Owner: ctoa
--

CREATE TABLE public.agent_runs (
    id integer NOT NULL,
    agent text NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    status text,
    message text
);


ALTER TABLE public.agent_runs OWNER TO ctoa;

--
-- Name: agent_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: ctoa
--

CREATE SEQUENCE public.agent_runs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agent_runs_id_seq OWNER TO ctoa;

--
-- Name: agent_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ctoa
--

ALTER SEQUENCE public.agent_runs_id_seq OWNED BY public.agent_runs.id;


--
-- Name: api_endpoints; Type: TABLE; Schema: public; Owner: ctoa
--

CREATE TABLE public.api_endpoints (
    id integer NOT NULL,
    server_id integer NOT NULL,
    path text NOT NULL,
    method text DEFAULT 'GET'::text NOT NULL,
    last_status integer,
    response_schema jsonb,
    last_checked timestamp with time zone
);


ALTER TABLE public.api_endpoints OWNER TO ctoa;

--
-- Name: api_endpoints_id_seq; Type: SEQUENCE; Schema: public; Owner: ctoa
--

CREATE SEQUENCE public.api_endpoints_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.api_endpoints_id_seq OWNER TO ctoa;

--
-- Name: api_endpoints_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ctoa
--

ALTER SEQUENCE public.api_endpoints_id_seq OWNED BY public.api_endpoints.id;


--
-- Name: daily_stats; Type: TABLE; Schema: public; Owner: ctoa
--

CREATE TABLE public.daily_stats (
    dt date DEFAULT CURRENT_DATE NOT NULL,
    modules_generated integer DEFAULT 0 NOT NULL,
    programs_generated integer DEFAULT 0 NOT NULL,
    avg_quality double precision DEFAULT 0 NOT NULL,
    launcher_day boolean DEFAULT false NOT NULL,
    released_at timestamp with time zone
);


ALTER TABLE public.daily_stats OWNER TO ctoa;

--
-- Name: game_data; Type: TABLE; Schema: public; Owner: ctoa
--

CREATE TABLE public.game_data (
    id integer NOT NULL,
    server_id integer NOT NULL,
    data_type text NOT NULL,
    raw jsonb NOT NULL,
    fetched_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.game_data OWNER TO ctoa;

--
-- Name: game_data_id_seq; Type: SEQUENCE; Schema: public; Owner: ctoa
--

CREATE SEQUENCE public.game_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.game_data_id_seq OWNER TO ctoa;

--
-- Name: game_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ctoa
--

ALTER SEQUENCE public.game_data_id_seq OWNED BY public.game_data.id;


--
-- Name: modules; Type: TABLE; Schema: public; Owner: ctoa
--

CREATE TABLE public.modules (
    id integer NOT NULL,
    server_id integer,
    task_id text NOT NULL,
    template text NOT NULL,
    output_file text,
    output_path text,
    status text DEFAULT 'QUEUED'::text NOT NULL,
    quality_score integer,
    test_log text,
    retry_count integer DEFAULT 0 NOT NULL,
    queued_at timestamp with time zone DEFAULT now() NOT NULL,
    generated_at timestamp with time zone,
    validated_at timestamp with time zone
);


ALTER TABLE public.modules OWNER TO ctoa;

--
-- Name: modules_id_seq; Type: SEQUENCE; Schema: public; Owner: ctoa
--

CREATE SEQUENCE public.modules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.modules_id_seq OWNER TO ctoa;

--
-- Name: modules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ctoa
--

ALTER SEQUENCE public.modules_id_seq OWNED BY public.modules.id;


--
-- Name: servers; Type: TABLE; Schema: public; Owner: ctoa
--

CREATE TABLE public.servers (
    id integer NOT NULL,
    url text NOT NULL,
    name text,
    game_type text DEFAULT 'unknown'::text,
    status text DEFAULT 'NEW'::text NOT NULL,
    scout_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.servers OWNER TO ctoa;

--
-- Name: servers_id_seq; Type: SEQUENCE; Schema: public; Owner: ctoa
--

CREATE SEQUENCE public.servers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.servers_id_seq OWNER TO ctoa;

--
-- Name: servers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ctoa
--

ALTER SEQUENCE public.servers_id_seq OWNED BY public.servers.id;


--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: ctoa
--

CREATE TABLE public.user_profiles (
    username text NOT NULL,
    role text NOT NULL,
    profile_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_profiles OWNER TO ctoa;

--
-- Name: accounts id; Type: DEFAULT; Schema: public; Owner: ctoa
--

ALTER TABLE ONLY public.accounts ALTER COLUMN id SET DEFAULT nextval('public.accounts_id_seq'::regclass);


--
-- Name: agent_runs id; Type: DEFAULT; Schema: public; Owner: ctoa
--

ALTER TABLE ONLY public.agent_runs ALTER COLUMN id SET DEFAULT nextval('public.agent_runs_id_seq'::regclass);


--
-- Name: api_endpoints id; Type: DEFAULT; Schema: public; Owner: ctoa
--

ALTER TABLE ONLY public.api_endpoints ALTER COLUMN id SET DEFAULT nextval('public.api_endpoints_id_seq'::regclass);


--
-- Name: game_data id; Type: DEFAULT; Schema: public; Owner: ctoa
--

ALTER TABLE ONLY public.game_data ALTER COLUMN id SET DEFAULT nextval('public.game_data_id_seq'::regclass);


--
-- Name: modules id; Type: DEFAULT; Schema: public; Owner: ctoa
--

ALTER TABLE ONLY public.modules ALTER COLUMN id SET DEFAULT nextval('public.modules_id_seq'::regclass);


--
-- Name: servers id; Type: DEFAULT; Schema: public; Owner: ctoa
--

ALTER TABLE ONLY public.servers ALTER COLUMN id SET DEFAULT nextval('public.servers_id_seq'::regclass);


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: ctoa
--

COPY public.accounts (id, username, password_hash, role, active, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agent_runs; Type: TABLE DATA; Schema: public; Owner: ctoa
--

COPY public.agent_runs (id, agent, started_at, finished_at, status, message) FROM stdin;
\.


--
-- Data for Name: api_endpoints; Type: TABLE DATA; Schema: public; Owner: ctoa
--

COPY public.api_endpoints (id, server_id, path, method, last_status, response_schema, last_checked) FROM stdin;
\.


--
-- Data for Name: daily_stats; Type: TABLE DATA; Schema: public; Owner: ctoa
--

COPY public.daily_stats (dt, modules_generated, programs_generated, avg_quality, launcher_day, released_at) FROM stdin;
\.


--
-- Data for Name: game_data; Type: TABLE DATA; Schema: public; Owner: ctoa
--

COPY public.game_data (id, server_id, data_type, raw, fetched_at) FROM stdin;
\.


--
-- Data for Name: modules; Type: TABLE DATA; Schema: public; Owner: ctoa
--

COPY public.modules (id, server_id, task_id, template, output_file, output_path, status, quality_score, test_log, retry_count, queued_at, generated_at, validated_at) FROM stdin;
\.


--
-- Data for Name: servers; Type: TABLE DATA; Schema: public; Owner: ctoa
--

COPY public.servers (id, url, name, game_type, status, scout_error, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: ctoa
--

COPY public.user_profiles (username, role, profile_json, created_at, updated_at) FROM stdin;
octo	operator	{"api_base": "", "refresh_seconds": 10}	2026-05-14 20:45:29.394137+00	2026-05-14 20:45:29.394137+00
cto	owner	{"api_base": "http://116.202.96.250:8787", "refresh_seconds": 10}	2026-05-14 17:49:55.033165+00	2026-05-14 21:14:50.560222+00
\.


--
-- Name: accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ctoa
--

SELECT pg_catalog.setval('public.accounts_id_seq', 1, false);


--
-- Name: agent_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ctoa
--

SELECT pg_catalog.setval('public.agent_runs_id_seq', 1, false);


--
-- Name: api_endpoints_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ctoa
--

SELECT pg_catalog.setval('public.api_endpoints_id_seq', 1, false);


--
-- Name: game_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ctoa
--

SELECT pg_catalog.setval('public.game_data_id_seq', 1, false);


--
-- Name: modules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ctoa
--

SELECT pg_catalog.setval('public.modules_id_seq', 1, false);


--
-- Name: servers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ctoa
--

SELECT pg_catalog.setval('public.servers_id_seq', 1, false);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: ctoa
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_username_key; Type: CONSTRAINT; Schema: public; Owner: ctoa
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_username_key UNIQUE (username);


--
-- Name: agent_runs agent_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: ctoa
--

ALTER TABLE ONLY public.agent_runs
    ADD CONSTRAINT agent_runs_pkey PRIMARY KEY (id);


--
-- Name: api_endpoints api_endpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: ctoa
--

ALTER TABLE ONLY public.api_endpoints
    ADD CONSTRAINT api_endpoints_pkey PRIMARY KEY (id);


--
-- Name: api_endpoints api_endpoints_server_id_path_key; Type: CONSTRAINT; Schema: public; Owner: ctoa
--

ALTER TABLE ONLY public.api_endpoints
    ADD CONSTRAINT api_endpoints_server_id_path_key UNIQUE (server_id, path);


--
-- Name: daily_stats daily_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: ctoa
--

ALTER TABLE ONLY public.daily_stats
    ADD CONSTRAINT daily_stats_pkey PRIMARY KEY (dt);


--
-- Name: game_data game_data_pkey; Type: CONSTRAINT; Schema: public; Owner: ctoa
--

ALTER TABLE ONLY public.game_data
    ADD CONSTRAINT game_data_pkey PRIMARY KEY (id);


--
-- Name: modules modules_pkey; Type: CONSTRAINT; Schema: public; Owner: ctoa
--

ALTER TABLE ONLY public.modules
    ADD CONSTRAINT modules_pkey PRIMARY KEY (id);


--
-- Name: modules modules_task_id_key; Type: CONSTRAINT; Schema: public; Owner: ctoa
--

ALTER TABLE ONLY public.modules
    ADD CONSTRAINT modules_task_id_key UNIQUE (task_id);


--
-- Name: servers servers_pkey; Type: CONSTRAINT; Schema: public; Owner: ctoa
--

ALTER TABLE ONLY public.servers
    ADD CONSTRAINT servers_pkey PRIMARY KEY (id);


--
-- Name: servers servers_url_key; Type: CONSTRAINT; Schema: public; Owner: ctoa
--

ALTER TABLE ONLY public.servers
    ADD CONSTRAINT servers_url_key UNIQUE (url);


--
-- Name: user_profiles user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: ctoa
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (username);


--
-- Name: game_data_server_type; Type: INDEX; Schema: public; Owner: ctoa
--

CREATE INDEX game_data_server_type ON public.game_data USING btree (server_id, data_type);


--
-- Name: servers servers_updated_at; Type: TRIGGER; Schema: public; Owner: ctoa
--

CREATE TRIGGER servers_updated_at BEFORE UPDATE ON public.servers FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: user_profiles user_profiles_updated_at; Type: TRIGGER; Schema: public; Owner: ctoa
--

CREATE TRIGGER user_profiles_updated_at BEFORE UPDATE ON public.user_profiles FOR EACH ROW EXECUTE FUNCTION public.trg_set_updated_at();


--
-- Name: api_endpoints api_endpoints_server_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ctoa
--

ALTER TABLE ONLY public.api_endpoints
    ADD CONSTRAINT api_endpoints_server_id_fkey FOREIGN KEY (server_id) REFERENCES public.servers(id) ON DELETE CASCADE;


--
-- Name: game_data game_data_server_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ctoa
--

ALTER TABLE ONLY public.game_data
    ADD CONSTRAINT game_data_server_id_fkey FOREIGN KEY (server_id) REFERENCES public.servers(id) ON DELETE CASCADE;


--
-- Name: modules modules_server_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ctoa
--

ALTER TABLE ONLY public.modules
    ADD CONSTRAINT modules_server_id_fkey FOREIGN KEY (server_id) REFERENCES public.servers(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict eW4yCDqWLXNPjvnwVv1UxdYMhiLu2SuI1GtsqmoJJfgUR8CRzGd3rk5z0gYUX9Z

